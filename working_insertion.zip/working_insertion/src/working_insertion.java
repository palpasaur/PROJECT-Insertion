import java.util.Scanner;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JButton;

public class working_insertion extends javax.swing.JFrame {
    public int[] arr;
    public int temp, j;
    private int currentStep = 0;
    private List<int[]> previousArrs = new ArrayList<>();
    private List<int[]> previousSwapIndices = new ArrayList<>();
    private int swapIndex1 = -1;
    private int swapIndex2 = -1;
    
    public working_insertion() {
        initComponents();
        
        JButton nextbtn = new JButton("Next");
        nextbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nextActionPerformed(e);
            }
        });
        
        JButton previousbtn = new JButton("Previous");
        previousbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                previousActionPerformed(e);
            }
        });
    }

    
public void Insertion(int[] arr, boolean isNext) {
    if (isNext && currentStep < arr.length * 3 && currentStep < previousArrs.size()) {
        // Update the array state from previousArrs
        arr = Arrays.copyOf(previousArrs.get(currentStep), arr.length);

        // Retrieve the previous swap indices
        int[] swapIndices = previousSwapIndices.get(currentStep);
        int swapIndex1 = swapIndices[0];
        int swapIndex2 = swapIndices[1];

        // Update the JTextArea with the step
        StringBuilder sb = new StringBuilder();
        sb.append("STEP ").append(currentStep + 1).append(": ");
        for (int k = 0; k < arr.length; k++) {
            if (k == swapIndex1 || k == swapIndex2) {
                sb.append("[").append(arr[k]).append("] ");
            } else {
                sb.append(arr[k]).append(" ");
            }
        }
        sb.append("(Swapped index: ").append(swapIndex1).append(", ").append(swapIndex2).append(")");
        Result.append(sb.toString());
        Result.append("\n");

        currentStep++;
    } else if (isNext && currentStep < arr.length * 5) {
        int swapIndex1 = -1;
        int swapIndex2 = -1;

        for (int j = 0; j < arr.length - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j + 1];
                arr[j + 1] = arr[j];
                arr[j] = temp;
                swapIndex1 = j;
                swapIndex2 = j + 1;

                // Update the JTextArea with the step
                previousArrs.add(Arrays.copyOf(arr, arr.length)); // Add the current array state to the list
                previousSwapIndices.add(new int[]{swapIndex1, swapIndex2}); // Add the current swap indices to the list

                StringBuilder sb = new StringBuilder();
                sb.append("STEP ").append(currentStep + 1).append(": ");
                for (int k = 0; k < arr.length; k++) {
                    if (k == swapIndex1 || k == swapIndex2) {
                        sb.append("[").append(arr[k]).append("] ");
                    } else {
                        sb.append(arr[k]).append(" ");
                    }
                }
                sb.append("(Swapped index: ").append(swapIndex1).append(", ").append(swapIndex2).append(")");
                Result.append(sb.toString());
                Result.append("\n");

                break;
            }
        }

        currentStep++;
    } else if (!isNext && currentStep > 0) {
        // Revert the previous step
        currentStep--;
        arr = Arrays.copyOf(previousArrs.get(currentStep - 1), arr.length); // Get the previous array state

        // Update the JTextArea by removing the last step and the current step
        String text = Result.getText();
        String[] lines = text.split("\\n");
        if (lines.length > 1) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < lines.length - 2; i++) {  // Remove two lines for the previous step and the current step
                sb.append(lines[i]);
                sb.append("\n");
            }
            Result.setText(sb.toString());
        }

        // Retrieve the previous swap indices
        int[] swapIndices = previousSwapIndices.get(currentStep - 1);
        int swapIndex1 = swapIndices[0];
        int swapIndex2 = swapIndices[1];

        // Update the JTextArea with the restored step
        StringBuilder sb = new StringBuilder();
        sb.append("STEP ").append(currentStep).append(": ");
        for (int k = 0; k < arr.length; k++) {
            if (k == swapIndex1 || k == swapIndex2) {
                sb.append("[").append(arr[k]).append("] ");
            } else {
                sb.append(arr[k]).append(" ");
            }
        }
        sb.append("(Swapped index: ").append(swapIndex1).append(", ").append(swapIndex2).append(")");
        Result.append(sb.toString());
        Result.append("\n");
    }
}







    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Result = new javax.swing.JTextArea();
        Sort = new javax.swing.JButton();
        arrayset = new javax.swing.JTextField();
        Label2 = new javax.swing.JLabel();
        reset = new javax.swing.JButton();
        next = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        previous = new javax.swing.JButton();
        description = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel1.setText("INSERTION SORTING");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Insertion Step");

        Result.setEditable(false);
        Result.setColumns(20);
        Result.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        Result.setRows(5);
        jScrollPane1.setViewportView(Result);

        Sort.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        Sort.setText("SORT!");
        Sort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SortActionPerformed(evt);
            }
        });

        arrayset.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        arrayset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                arraysetActionPerformed(evt);
            }
        });

        Label2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Label2.setText("Enter numbers:");

        reset.setText("Reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        next.setText("Next step");
        next.setEnabled(false);
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Consolas", 3, 18)); // NOI18N
        jLabel2.setText("Seperate the numbers with comma");

        previous.setText("Previous Step");
        previous.setEnabled(false);
        previous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousActionPerformed(evt);
            }
        });

        description.setText("SHOW DESCRIPTION");
        description.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                descriptionActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("/ Description:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Label2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(arrayset, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Sort, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(195, 195, 195)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(281, 281, 281)
                        .addComponent(description))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(244, 244, 244)
                        .addComponent(jLabel1)))
                .addGap(74, 74, 74))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(reset, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(previous, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(next, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(141, 141, 141))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(description)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(arrayset, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Label2)
                    .addComponent(Sort))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 352, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(reset, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(next, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(previous, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void arraysetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_arraysetActionPerformed
        
    }//GEN-LAST:event_arraysetActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
         //GETTING THE ARRAY IN THE JTEXTAREA
         String input = arrayset.getText();
         String[] numbers = input.split(",");
         int[] ar = new int[numbers.length];
    
            try{
                for(int i=0; i<numbers.length;i++){
                    ar[i] = Integer.parseInt(numbers[i].trim());
                }
                StringBuilder sb = new StringBuilder();
                Result.append("Given Numbers: " + input + "\n");
                
                arr = ar;
                
                next.setEnabled(true);
                previous.setEnabled(true);
            }catch(Exception e){    
                JOptionPane.showMessageDialog(null, "exceeding element!");
            }
    }//GEN-LAST:event_SortActionPerformed

    private void nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextActionPerformed
        Insertion(arr, true);
    }//GEN-LAST:event_nextActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        //REST ALL IN JTEXTAREA
        Result.setText(" ");
        arrayset.setText("");
        if(currentStep > 0){
            currentStep = 0;
            previousArrs.clear();
            previousSwapIndices.clear();
        arr = new int[arr.length];
        System.arraycopy(arr, 0, arr, 0, arr.length);
        
        }
        next.setEnabled(false);
        previous.setEnabled(false);
    }//GEN-LAST:event_resetActionPerformed

    private void descriptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_descriptionActionPerformed
        StringBuilder sb = new StringBuilder();
        Result.append("Insertion sort is a simple comparison-based sorting algorithm. \n"
                + "It works by dividing the input into two parts: a sorted subarray \n"
                + "and an unsorted subarray Initially, the sorted subarray contains \n"
                + "only the first element of the input array, and the remaining \n"
                + "elements are considered part of the unsorted subarray.");
        
    }//GEN-LAST:event_descriptionActionPerformed

    private void previousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousActionPerformed
        Insertion(arr, false);
    }//GEN-LAST:event_previousActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new working_insertion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label2;
    private javax.swing.JTextArea Result;
    private javax.swing.JButton Sort;
    private javax.swing.JTextField arrayset;
    private javax.swing.JButton description;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton next;
    private javax.swing.JButton previous;
    private javax.swing.JButton reset;
    // End of variables declaration//GEN-END:variables
}
